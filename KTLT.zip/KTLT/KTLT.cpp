#include <iostream>
using namespace std;

int main() {
    std::string chuoi = "Luong Thanh Ngoc Nhu";
    
    for (int i = 0; i < chuoi.length(); i++) {
        if (chuoi[i] >= 'a' && chuoi[i] <= 'z') {
            chuoi[i] = chuoi[i] - 'a' + 'A';  
        }
    }
    
    std::cout << chuoi << std::endl;
    return 0;
}

