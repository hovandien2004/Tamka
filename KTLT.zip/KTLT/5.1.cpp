#include <iostream>
#include <string>
using namespace std;

bool kiemTraDoiXung(const std::string& chuoi) {
    int start = 0, end = chuoi.length() - 1;
    while (start < end) {
        if (chuoi[start] != chuoi[end]) return false;
        start++; end--;
    }
    return true;
}

int main() {
    std::string chuoi;
    std::cout << "Nhap chuoi: ";
    std::getline(std::cin, chuoi);
    
    if (kiemTraDoiXung(chuoi))
        std::cout << "Chuoi doi xung" << std::endl;
    else
        std::cout << "Chuoi khong doi xung" << std::endl;
    return 0;
}

