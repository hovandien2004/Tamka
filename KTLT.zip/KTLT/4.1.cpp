#include <iostream>
#include <string>
using namespace std;


void saoChepChuoi(const std::string& chuoi1, std::string& chuoi2) {
    chuoi2.clear();
    for (int i = 0; i < chuoi1.length(); i++) {
        chuoi2 += chuoi1[i];
    }
}

int main() {
    std::string chuoi1 = "ngoc nhu";
    std::string chuoi2;
    
    saoChepChuoi(chuoi1, chuoi2);
    
    std::cout << "Chuoi 2: " << chuoi2 << std::endl;
    
    return 0;
}

