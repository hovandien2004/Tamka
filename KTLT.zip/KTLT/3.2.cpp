#include <iostream>
#include <sstream>
#include <string>
using namespace std;

void inMoiTuMoiDong(const std::string& chuoi) {
    std::stringstream ss(chuoi);
    std::string tu;
    while (ss >> tu) {
        std::cout << tu << std::endl; 
    }
}

int main() {
    std::string chuoi;
    std::cout << "Nhap chuoi: ";
    std::getline(std::cin, chuoi);
    inMoiTuMoiDong(chuoi);
    
    return 0;
}

