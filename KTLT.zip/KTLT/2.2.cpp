#include <iostream>
#include <string>
using namespace std;

int main() {
    std::string chuoi;
    char ki_tu;
    int dem = 0;

    std::cout << "Nhap chuoi: ";
    std::getline(std::cin, chuoi);

    std::cout << "Nhap vao ky tu can tim: ";
    std::cin >> ki_tu;

    for (int i = 0; i < chuoi.length(); i++) {
        if (chuoi[i] == ki_tu) {
            dem++;
        }
    }

    std::cout << "Ky tu '" << ki_tu << "' xuat hien " << dem << " lan trong chuoi." << std::endl;

    return 0;
}

