#include <iostream>
#include <string>

int main() {
    std::string chuoi;
    char ki_tu;
    int dem = 0;

    std::cout << "Nh?p v�o chu?i: ";
    std::getline(std::cin, chuoi);

    std::cout << "Nh?p v�o k� t? c?n t�m: ";
    std::cin >> ki_tu;

    for (int i = 0; i < chuoi.length(); i++) {
        if (chuoi[i] == ki_tu) {
            dem++;
        }
    }

    std::cout << "K� t? '" << ki_tu << "' xu?t hi?n " << dem << " l?n trong chu?i." << std::endl;

    return 0;
}

