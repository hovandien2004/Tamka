#include <iostream>
#include <string>
using namespace std;

int main() {
    std::string chuoi;
    std::cout << "Nhap chuoi: ";
    std::getline(std::cin, chuoi);
    std::cout << "Do dai chuoi la: " << chuoi.length() << std::endl;
    return 0;
}

