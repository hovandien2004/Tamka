package bo;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import bean.cha;
import bean.giangvienbean;
import bean.nhanvienbean;
import dao.nguoidao;

public class nguoibo {
	nguoidao ndao = new nguoidao();
	ArrayList<cha> ds;
	public ArrayList<cha> getds() throws Exception{
		ds = ndao.getds();
		return ds;
	}
	
	public void hienthi() throws Exception{
		for(cha n:ds) {
			System.out.println(n.toString());
		}
	}
	
	public void luufilekq() throws Exception{
		try {
			FileWriter fw = new FileWriter("ketqua.txt");
			BufferedWriter bw = new BufferedWriter(fw);
			for(cha n:ds) {
				bw.write(n.toString()+"\n");
			}bw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	ArrayList<cha> ds1 = new ArrayList<cha>();
	public void cau3() throws Exception{
		
		FileReader fr = new FileReader("ketqua.txt");
		BufferedReader br = new BufferedReader(fr);
		while(true) {
			String st = br.readLine();
			if(st == null || st == "") break;
			String[] t = st.split("[;]");
			if(t.length == 4) {
				nhanvienbean nv = new nhanvienbean(t[0], t[1], t[2], Double.parseDouble(t[3]));
				ds1.add(nv);
			}
			if(t.length == 5) {
				giangvienbean gv = new giangvienbean(t[0], t[1], t[2], Double.parseDouble(t[3]), Double.parseDouble(t[4]));
				ds1.add(gv);
			}
		}br.close();
		
		
		System.out.println("\nDanh sach nhan vien: ");
		for(cha n:ds) {
			if(n instanceof nhanvienbean) {
				System.out.println(n.toString());
			}
		}
		System.out.println("Danh sach giang vien: ");
		for(cha n:ds) {
			if(n instanceof giangvienbean) {
				System.out.println(n.toString());
			}
		}
		
	}
	public static Connection cn;
	public void ketnoi() throws Exception {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		System.out.println("Da xac dinh he qtcsdl");
		cn = DriverManager.getConnection("jdbc:sqlserver://DIEN\\SQLEXPRESS:1433;databaseName=ontap; user=sa; password=1812");
		System.out.println("Da ket noi");
	}
	
	
	public void napsqlNhanVien(String manv, String hoten, String loaihd, double hsl) throws Exception {
		String sql = "insert into NhanVien(manv,hoten,loaihd,hsl) values(?,?,?,?)";
		PreparedStatement cmd = cn.prepareStatement(sql);
		cmd.setString(1, manv);
		cmd.setString(2, hoten);
		cmd.setString(3, loaihd);
		cmd.setDouble(4, hsl);
		cmd.executeUpdate();
	}
	
	public void napsqlGiangVien(String magv, String hoten, String loaihd, double hsl, double phucap) throws Exception {
		String sql = "insert into GiangVien(magv,hoten,loaihd,hsl,phucap) values(?,?,?,?,?)";
		PreparedStatement cmd = cn.prepareStatement(sql);
		cmd.setString(1, magv);
		cmd.setString(2, hoten);
		cmd.setString(3, loaihd);
		cmd.setDouble(4, hsl);
		cmd.setDouble(5, phucap);
		cmd.executeUpdate();
	}
	
	
	public void cau4() throws Exception{
		for(cha n : ds1) {
			if(n instanceof nhanvienbean) {
				String[] nv = new String[4];
				nv[0] = ((nhanvienbean) n).getManv();
				nv[1] = ((nhanvienbean) n).getHoten();
				nv[2] = ((nhanvienbean) n).getLoaihd();
				nv[3] = String.valueOf(((nhanvienbean) n).getHsl());
				napsqlNhanVien(nv[0], nv[1], nv[2], Double.parseDouble(nv[3]));
			}
			if(n instanceof giangvienbean) {
				String[] gv = new String[5];
				gv[0] = ((giangvienbean) n).getMagv();
				gv[1] = ((giangvienbean) n).getHoten();
				gv[2] = ((giangvienbean) n).getLoaihd();
				gv[3] = String.valueOf(((giangvienbean) n).getHsl());
				gv[4] = String.valueOf(((giangvienbean) n).getPhucap());
				napsqlGiangVien(gv[0], gv[1], gv[2], Double.parseDouble(gv[3]), Double.parseDouble(gv[4]));
			}
			
		}
	}
	
	
	public void cau5() throws Exception{
		String sql = "Select * from NhanVien";
		PreparedStatement cmd = cn.prepareStatement(sql);
		ResultSet rs = cmd.executeQuery();
		int demhd = 0;
		int demct = 0;
		while(rs.next()) {
			String[] tam = new String[4];
			tam[0] = rs.getString("manv");
			tam[1] = rs.getString("hoten");
			tam[2] = rs.getString("loaihd");
			tam[3] = String.valueOf(rs.getDouble("hsl"));
			if(tam[2].equals("hopdong")) {
				demhd++;
			}
			if(tam[2].equals("chinhthuc")) {
				demct++;
			}
		}System.out.println("So luong hop dong chinh thuc: " + demct);
		System.out.println("So luong hop dong hop dong: " + demhd);
	}
	
}
