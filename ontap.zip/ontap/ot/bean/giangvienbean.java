package bean;

public class giangvienbean extends cha{
	private String magv;
	private String loaihd;
	private double hsl;
	private double phucap;
	
	
	public giangvienbean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public giangvienbean(String magv, String hoten, String loaihd, double hsl, double phucap) {
		super(hoten);
		this.magv = magv;
		this.loaihd = loaihd;
		this.hsl = hsl;
		this.phucap = phucap;
	}
	public String getMagv() {
		return magv;
	}
	public void setMagv(String magv) {
		this.magv = magv;
	}
	public String getLoaihd() {
		return loaihd;
	}
	public void setLoaihd(String loaihd) {
		this.loaihd = loaihd;
	}
	public double getHsl() {
		return hsl;
	}
	public void setHsl(double hsl) {
		this.hsl = hsl;
	}
	public double getPhucap() {
		return phucap;
	}
	public void setPhucap(double phucap) {
		this.phucap = phucap;
	}
	@Override
	public String toString() {
		return magv + ";"+ super.toString() + ";" + loaihd + ";" + hsl + ";" + phucap;
	}
	
	
}
