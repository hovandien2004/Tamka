package bean;

public class nhanvienbean extends cha {
	private String manv;
	private String loaihd;
	private double hsl;
	public nhanvienbean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public nhanvienbean(String manv, String hoten, String loaihd, double hsl) {
		super(hoten);
		this.manv = manv;
		this.loaihd = loaihd;
		this.hsl = hsl;
	}
	public String getManv() {
		return manv;
	}
	public void setManv(String manv) {
		this.manv = manv;
	}
	public String getLoaihd() {
		return loaihd;
	}
	public void setLoaihd(String loaihd) {
		this.loaihd = loaihd;
	}
	public double getHsl() {
		return hsl;
	}
	public void setHsl(double hsl) {
		this.hsl = hsl;
	}
	@Override
	public String toString() {
		return manv + ";" + super.toString()+";"+ loaihd + ";" + hsl;
	}
	
	
}
