package bean;
import java.util.ArrayList;
public class cha {
	private String hoten;

	public cha() {
		super();
		// TODO Auto-generated constructor stub
	}

	public cha(String hoten) {
		super();
		this.hoten = hoten;
	}

	public String getHoten() {
		return hoten;
	}

	public void setHoten(String hoten) {
		this.hoten = hoten;
	}

	@Override
	public String toString() {
		return hoten;
	}
	
	
}
