package view;

import java.util.ArrayList;

import bean.cha;
import bo.nguoibo;

public class nguoiview {

	public static void main(String[] args) {
		try {
			nguoibo nbo = new nguoibo();
			ArrayList<cha> ds= nbo.getds();
			System.out.println("Danh sach: ");
			nbo.hienthi();
			nbo.luufilekq();
			nbo.cau3();
			nbo.ketnoi();
			//nbo.cau4();
			nbo.cau5();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
