package dao;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

import bean.cha;
import bean.giangvienbean;
import bean.nhanvienbean;

public class nguoidao {
	public ArrayList<cha> getds() throws Exception {
		ArrayList<cha> ds = new ArrayList<cha>();
		try {
			FileReader fr = new FileReader("ds.txt");
			BufferedReader br = new BufferedReader(fr);
			while(true) {
				String dong = br.readLine();
				if(dong == null || dong == "") break;
				String[] t = dong.split("[;]");
				if(t.length == 4 && (t[2].equals("chinhthuc") || t[2].equals("hopdong"))) {
					nhanvienbean nv = new nhanvienbean(t[0], t[1], t[2], Double.parseDouble(t[3]));
					
					ds.add(nv);
				}
				if(t.length == 5 && (t[2].equals("chinhthuc") || t[2].equals("hopdong"))) {
					giangvienbean gv = new giangvienbean(t[0], t[1], t[2],Double.parseDouble(t[3]), Double.parseDouble(t[4]));
					
					//gv.setPhucap(Double.parseDouble(t[4]));
					ds.add(gv);
				}
			}br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ds;
	}
	
	public ArrayList<nhanvienbean> getnv() throws Exception {
		ArrayList<nhanvienbean> tam = new ArrayList<nhanvienbean>();
		for(cha n:getds()) {
			if(n instanceof nhanvienbean) {
				tam.add((nhanvienbean)n);
			}
		}
		return tam;
	}
	public ArrayList<giangvienbean> getgv() throws Exception {
		ArrayList<giangvienbean> tam = new ArrayList<giangvienbean>();
		for(cha n:getds()) {
			if(n instanceof giangvienbean) {
				tam.add((giangvienbean)n);
			}
		}
		return tam;
	}
	
	
}
